export type EmployeeRole =
  | 'owner'
  | 'marketing_manager'
  | 'sales_supervisor'
  | 'order_taker'
  | 'salesperson';

export interface EmployeeProfile {
  id: string;
  full_name: string;
  phone: string | null;
  role: string;
  active: boolean;
  created_at: string;
}

export interface Customer {
  id: string;
  full_name: string;
  phone: string | null;
  email: string | null;
  address: string | null;
  created_at: string;
}

export interface PaintProduct {
  id: string;
  product_code: string | null;
  product_name: string;
  category: string | null;
  description: string | null;
  price_per_gallon: number;
  price_per_litre: number;
  coverage_m2_per_gallon: number | null;
  coverage_m2_per_litre: number | null;
  commission_per_gallon: number;
  commission_per_litre: number;
  active: boolean;
  created_at: string;
}

export interface Sale {
  id: string;
  sale_number: string;
  customer_id: string;
  marketing_manager_id: string | null;
  sales_supervisor_id: string | null;
  order_taker_id: string | null;
  salesperson_id: string | null;
  total_amount: number;
  currency: string;
  status: string;
  created_at: string;
  customer?: Customer;
  sale_items?: SaleItem[];
  payments?: Payment[];
}

export interface SaleItem {
  id: string;
  sale_id: string;
  product_id: string;
  quantity: number;
  quantity_unit: string;
  unit_price: number;
  commission_rate: number;
  created_at: string;
  product?: PaintProduct;
}

export interface Payment {
  id: string;
  sale_id: string;
  amount: number;
  payment_method: string;
  reference_number: string | null;
  recorded_by: string | null;
  payment_date: string;
  status: string;
  created_at: string;
}

export interface CommissionEntry {
  id: string;
  payment_id: string;
  sale_id: string;
  employee_id: string;
  employee_role: string;
  commission_percent: number;
  commission_amount: number;
  status: string;
  created_at: string;
  approval_status: string | null;
  approved_by: string | null;
  approved_at: string | null;
  paid_by: string | null;
  paid_at: string | null;
  payout_reference: string | null;
  employee?: EmployeeProfile;
  sale?: Pick<Sale, 'id' | 'sale_number' | 'total_amount' | 'created_at'>;
  payment?: Pick<Payment, 'id' | 'amount' | 'payment_date' | 'payment_method'>;
}

// Compatibility aliases used by the exported page components.
export type Employee = EmployeeProfile;
export type Product = PaintProduct;
export type Commission = CommissionEntry;
export type PaymentMethod = 'cash' | 'bank_transfer' | 'mobile_money' | 'check' | 'other';
export type ProductUnit = 'gallon' | 'litre';
export interface SaleAssignment {
  id: string;
  sale_id: string;
  employee_id: string;
  role: EmployeeRole;
  employee?: EmployeeProfile;
}
