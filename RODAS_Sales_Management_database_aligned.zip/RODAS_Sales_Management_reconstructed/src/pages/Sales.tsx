import { useEffect, useMemo, useState } from 'react';
import { Plus, ShoppingCart, Loader2 } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';
import { ROLE_LABELS, formatCurrency, formatDate, SALE_STATUS_COLORS, SALE_STATUS_LABELS } from '@/lib/constants';
import { PageHeader, Button, Modal, Input, Select, LoadingSpinner, ErrorState, EmptyState, Badge } from '@/components/ui';
import type { Customer, EmployeeProfile, PaintProduct, Sale, EmployeeRole, ProductUnit } from '@/types';

interface LineItem { key: string; product_id: string; unit: ProductUnit; quantity: string; unit_price: string; }
const ASSIGN_ROLES: { value: EmployeeRole; label: string }[] = [
  { value: 'marketing_manager', label: 'Marketing Manager' },
  { value: 'sales_supervisor', label: 'Sales Supervisor' },
  { value: 'order_taker', label: 'Order Taker' },
  { value: 'salesperson', label: 'Salesperson' },
];
const today = () => new Date().toISOString().slice(0, 10);

export default function Sales() {
  const { user } = useAuth();
  const [sales, setSales] = useState<Sale[]>([]);
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [products, setProducts] = useState<PaintProduct[]>([]);
  const [employees, setEmployees] = useState<EmployeeProfile[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [showForm, setShowForm] = useState(false);
  const [saving, setSaving] = useState(false);
  const [customerId, setCustomerId] = useState('');
  const [saleDate, setSaleDate] = useState(today());
  const [amountPaid, setAmountPaid] = useState('0');
  const [items, setItems] = useState<LineItem[]>([]);
  const [assignments, setAssignments] = useState<Record<EmployeeRole, string>>({ marketing_manager: '', sales_supervisor: '', order_taker: '', salesperson: '' });

  const load = async () => {
    setLoading(true); setError(null);
    const [s, c, p, e] = await Promise.all([
      supabase.from('sales').select('*, customer:customers(*), sale_items(*), payments(*)').order('created_at', { ascending: false }),
      supabase.from('customers').select('*').order('full_name'),
      supabase.from('paint_products').select('*').eq('active', true).order('product_name'),
      supabase.from('employee_profiles').select('*').eq('active', true).order('full_name'),
    ]);
    const firstError = s.error ?? c.error ?? p.error ?? e.error;
    if (firstError) setError(firstError.message);
    setSales((s.data ?? []) as unknown as Sale[]); setCustomers((c.data ?? []) as Customer[]);
    setProducts((p.data ?? []) as PaintProduct[]); setEmployees((e.data ?? []) as EmployeeProfile[]);
    setLoading(false);
  };
  useEffect(() => { void load(); }, []);

  const total = useMemo(() => items.reduce((sum, it) => sum + (Number(it.quantity) || 0) * (Number(it.unit_price) || 0), 0), [items]);
  const paid = Number(amountPaid) || 0;
  const reset = () => { setCustomerId(''); setSaleDate(today()); setAmountPaid('0'); setItems([{ key: crypto.randomUUID(), product_id: '', unit: 'gallon', quantity: '1', unit_price: '0' }]); setAssignments({ marketing_manager: '', sales_supervisor: '', order_taker: '', salesperson: '' }); };
  const openCreate = () => { reset(); setShowForm(true); };
  const updateItem = (key: string, field: keyof LineItem, value: string) => setItems((old) => old.map((it) => {
    if (it.key !== key) return it;
    const next: LineItem = { ...it, [field]: value } as LineItem;
    if (field === 'product_id' || field === 'unit') {
      const prod = products.find((x) => x.id === (field === 'product_id' ? value : it.product_id));
      if (prod) next.unit_price = String((field === 'unit' ? value : it.unit) === 'gallon' ? prod.price_per_gallon : prod.price_per_litre);
    }
    return next;
  }));

  const handleSave = async (ev: React.FormEvent) => {
    ev.preventDefault(); setSaving(true); setError(null);
    if (!customerId) { setError('Select a customer.'); setSaving(false); return; }
    if (!items.length || items.some((x) => !x.product_id || Number(x.quantity) <= 0 || Number(x.unit_price) < 0)) { setError('Add valid products and quantities.'); setSaving(false); return; }
    if (paid < 0 || paid > total) { setError('Initial payment must be between zero and the sale total.'); setSaving(false); return; }
    const saleNumber = `RDS-${new Date().getFullYear()}-${String(Date.now()).slice(-6)}`;
    const salePayload = {
      sale_number: saleNumber, customer_id: customerId,
      marketing_manager_id: assignments.marketing_manager || null,
      sales_supervisor_id: assignments.sales_supervisor || null,
      order_taker_id: assignments.order_taker || null,
      salesperson_id: assignments.salesperson || null,
      total_amount: total, currency: 'ETB', status: paid >= total ? 'paid' : paid > 0 ? 'partial' : 'pending',
    };
    const { data: sale, error: saleError } = await supabase.from('sales').insert(salePayload).select().single();
    if (saleError || !sale) { setError(saleError?.message ?? 'Could not create sale.'); setSaving(false); return; }
    const rows = items.map((it) => {
      const product = products.find((p) => p.id === it.product_id)!;
      return { sale_id: sale.id, product_id: it.product_id, quantity: Number(it.quantity), quantity_unit: it.unit, unit_price: Number(it.unit_price), commission_rate: Number(it.unit === 'gallon' ? product.commission_per_gallon : product.commission_per_litre) };
    });
    const { error: itemError } = await supabase.from('sale_items').insert(rows);
    if (itemError) { setError(`Sale was created, but its items failed to save: ${itemError.message}`); setSaving(false); return; }
    if (paid > 0) {
      const { error: paymentError } = await supabase.from('payments').insert({ sale_id: sale.id, amount: paid, payment_method: 'cash', reference_number: null, recorded_by: user?.id ?? null, payment_date: saleDate, status: 'completed' });
      if (paymentError) { setError(`Sale was created, but its initial payment failed: ${paymentError.message}`); setSaving(false); return; }
    }
    setSaving(false); setShowForm(false); await load();
  };

  if (loading) return <LoadingSpinner label="Loading sales…" />;
  return <div>
    <PageHeader title="Sales" subtitle="Record sales and view sales history." action={<Button onClick={openCreate}><Plus className="w-4 h-4" /> New Sale</Button>} />
    {error && <div className="mb-4"><ErrorState message={error} /></div>}
    {sales.length === 0 ? <div className="bg-white rounded-xl border border-slate-200"><EmptyState icon={<ShoppingCart className="w-7 h-7" />} title="No sales yet" subtitle="Record your first sale to get started." /></div> :
      <div className="space-y-3">{sales.map((s) => {
        const paidAmount = (s.payments ?? []).filter((p) => ['completed', 'confirmed', 'approved'].includes(p.status)).reduce((sum, p) => sum + Number(p.amount), 0);
        const balance = Math.max(0, Number(s.total_amount) - paidAmount);
        return <div key={s.id} className="bg-white rounded-xl border border-slate-200 p-4 shadow-sm">
          <div className="flex items-center justify-between gap-3"><div><div className="flex gap-2 items-center"><b>{s.sale_number}</b><Badge className={SALE_STATUS_COLORS[s.status] ?? 'bg-slate-100 text-slate-700'}>{SALE_STATUS_LABELS[s.status] ?? s.status}</Badge></div><p className="text-sm text-slate-500 mt-1">{s.customer?.full_name ?? '—'} · {formatDate(s.created_at)} · {s.sale_items?.length ?? 0} item(s)</p></div><div className="text-right"><b>{formatCurrency(Number(s.total_amount), s.currency)}</b><p className="text-xs text-amber-700">Balance: {formatCurrency(balance, s.currency)}</p></div></div>
        </div>;
      })}</div>}
    <Modal open={showForm} onClose={() => setShowForm(false)} title="Create New Sale" size="lg">
      <form onSubmit={handleSave} className="space-y-4">
        <Select label="Customer" value={customerId} onChange={setCustomerId} options={customers.map((c) => ({ value: c.id, label: c.full_name }))} required />
        <Input label="Sale date" type="date" value={saleDate} onChange={setSaleDate} required />
        <div className="space-y-3">{items.map((it) => <div key={it.key} className="grid grid-cols-2 gap-3 border rounded-lg p-3">
          <div className="col-span-2"><Select label="Product" value={it.product_id} onChange={(v) => updateItem(it.key, 'product_id', v)} options={products.map((p) => ({ value: p.id, label: p.product_name }))} required /></div>
          <Select label="Unit" value={it.unit} onChange={(v) => updateItem(it.key, 'unit', v)} options={[{ value: 'gallon', label: 'Gallon' }, { value: 'litre', label: 'Litre' }]} />
          <Input label="Quantity" type="number" min="0.001" step="0.001" value={it.quantity} onChange={(v) => updateItem(it.key, 'quantity', v)} required />
          <Input label="Unit price (ETB)" type="number" min="0" step="0.01" value={it.unit_price} onChange={(v) => updateItem(it.key, 'unit_price', v)} required />
          <Button type="button" variant="ghost" onClick={() => setItems((old) => old.filter((x) => x.key !== it.key))}>Remove item</Button>
        </div>)}<Button type="button" variant="secondary" onClick={() => setItems((old) => [...old, { key: crypto.randomUUID(), product_id: '', unit: 'gallon', quantity: '1', unit_price: '0' }])}><Plus className="w-4 h-4" /> Add product</Button></div>
        <div className="rounded-lg bg-slate-50 p-3 font-semibold flex justify-between"><span>Sale total</span><span>{formatCurrency(total, 'ETB')}</span></div>
        <Input label="Initial payment (ETB)" type="number" min="0" max={total} step="0.01" value={amountPaid} onChange={setAmountPaid} />
        <div className="border-t pt-3"><p className="font-semibold mb-2">Assign employees (optional)</p><div className="grid sm:grid-cols-2 gap-3">{ASSIGN_ROLES.map((r) => <Select key={r.value} label={r.label} value={assignments[r.value]} onChange={(v) => setAssignments((old) => ({ ...old, [r.value]: v }))} options={[{ value: '', label: 'Not assigned' }, ...employees.filter((e) => e.role === r.value).map((e) => ({ value: e.id, label: e.full_name }))]} />)}</div></div>
        {error && <ErrorState message={error} />}
        <div className="flex justify-end gap-3"><Button type="button" variant="secondary" onClick={() => setShowForm(false)}>Cancel</Button><Button type="submit" disabled={saving}>{saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Plus className="w-4 h-4" />}{saving ? 'Saving…' : 'Save Sale'}</Button></div>
      </form>
    </Modal>
  </div>;
}
