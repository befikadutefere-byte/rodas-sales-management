import { useEffect, useState } from 'react';
import { UserPlus, Phone, Mail, MapPin, Pencil, Trash2, Loader2, UserCircle, Search } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';
import { formatDate } from '@/lib/constants';
import { PageHeader, Button, Modal, Input, Textarea, LoadingSpinner, ErrorState, EmptyState } from '@/components/ui';
import type { Customer } from '@/types';

export default function Customers() {
  const { user } = useAuth();
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [search, setSearch] = useState('');
  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState<Customer | null>(null);

  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [address, setAddress] = useState('');
  const [saving, setSaving] = useState(false);

  const load = async () => {
    setLoading(true);
    const { data, error } = await supabase.from('customers').select('*').order('created_at', { ascending: false });
    if (error) setError(error.message);
    else setCustomers((data ?? []) as Customer[]);
    setLoading(false);
  };

  useEffect(() => { load(); }, []);

  const openCreate = () => {
    setEditing(null);
    setName(''); setPhone(''); setEmail(''); setAddress('');
    setShowForm(true);
  };

  const openEdit = (c: Customer) => {
    setEditing(c);
    setName(c.full_name); setPhone(c.phone ?? ''); setEmail(c.email ?? ''); setAddress(c.address ?? '');
    setShowForm(true);
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    setError(null);
    const payload = {
      full_name: name,
      phone: phone || null,
      email: email || null,
      address: address || null,
    };
    let res;
    if (editing) {
      res = await supabase.from('customers').update(payload).eq('id', editing.id);
    } else {
      res = await supabase.from('customers').insert(payload);
    }
    setSaving(false);
    if (res.error) { setError(res.error.message); return; }
    setShowForm(false);
    await load();
  };

  const handleDelete = async (c: Customer) => {
    if (!confirm(`Delete customer "${c.full_name}"? This cannot be undone.`)) return;
    const { error } = await supabase.from('customers').delete().eq('id', c.id);
    if (error) { setError(error.message); return; }
    await load();
  };

  const filtered = customers.filter((c) =>
    c.full_name.toLowerCase().includes(search.toLowerCase()) ||
    (c.phone ?? '').includes(search) ||
    (c.email ?? '').toLowerCase().includes(search.toLowerCase()),
  );

  if (loading) return <LoadingSpinner label="Loading customers…" />;

  return (
    <div>
      <PageHeader
        title="Customers"
        subtitle="Manage your customer database."
        action={<Button onClick={openCreate}><UserPlus className="w-4 h-4" /> Add Customer</Button>}
      />

      {error && <div className="mb-4"><ErrorState message={error} /></div>}

      <div className="mb-4 relative max-w-sm">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
        <input
          type="text"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Search by name, phone, or email…"
          className="w-full pl-11 pr-4 py-2.5 rounded-lg border border-slate-300 bg-white text-slate-900 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-600 focus:border-transparent transition"
        />
      </div>

      {filtered.length === 0 ? (
        <div className="bg-white rounded-xl border border-slate-200">
          <EmptyState icon={<UserCircle className="w-7 h-7" />} title={search ? "No matching customers" : "No customers yet"} subtitle={search ? "Try a different search." : "Add your first customer to get started."} />
        </div>
      ) : (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {filtered.map((c) => (
            <div key={c.id} className="bg-white rounded-xl border border-slate-200 p-5 shadow-sm hover:shadow-md transition">
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-11 h-11 rounded-full bg-blue-100 flex items-center justify-center font-bold text-blue-600">
                    {c.full_name.charAt(0).toUpperCase()}
                  </div>
                  <div>
                    <p className="font-semibold text-slate-900">{c.full_name}</p>
                    <p className="text-xs text-slate-500">Added {formatDate(c.created_at)}</p>
                  </div>
                </div>
              </div>
              <div className="mt-4 space-y-1.5 text-sm text-slate-600">
                {c.phone && <p className="flex items-center gap-2"><Phone className="w-4 h-4 text-slate-400" /> {c.phone}</p>}
                {c.email && <p className="flex items-center gap-2"><Mail className="w-4 h-4 text-slate-400" /> <span className="truncate">{c.email}</span></p>}
                {c.address && <p className="flex items-start gap-2"><MapPin className="w-4 h-4 text-slate-400 mt-0.5 flex-shrink-0" /> {c.address}</p>}
              </div>
              <div className="mt-4 pt-4 border-t border-slate-100 flex gap-2">
                <Button variant="secondary" size="sm" onClick={() => openEdit(c)}><Pencil className="w-3.5 h-3.5" /> Edit</Button>
                <Button variant="ghost" size="sm" onClick={() => handleDelete(c)}><Trash2 className="w-3.5 h-3.5 text-rose-500" /></Button>
              </div>
            </div>
          ))}
        </div>
      )}

      <Modal open={showForm} onClose={() => setShowForm(false)} title={editing ? 'Edit Customer' : 'Add Customer'}>
        <form onSubmit={handleSave} className="space-y-4">
          <Input label="Customer Name" value={name} onChange={setName} required placeholder="ABC Hardware Store" />
          <Input label="Phone" value={phone} onChange={setPhone} placeholder="+1 555-0100" />
          <Input label="Email" type="email" value={email} onChange={setEmail} placeholder="contact@abchardware.com" />
          <Textarea label="Address" value={address} onChange={setAddress} rows={2} placeholder="123 Main Street, Springfield" />
          {error && <ErrorState message={error} />}
          <div className="flex justify-end gap-3 pt-2">
            <Button variant="secondary" onClick={() => setShowForm(false)}>Cancel</Button>
            <Button type="submit" disabled={saving}>
              {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : null}
              {saving ? 'Saving…' : editing ? 'Save Changes' : 'Add Customer'}
            </Button>
          </div>
        </form>
      </Modal>
    </div>
  );
}
