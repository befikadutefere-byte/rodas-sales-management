import { useEffect, useState } from 'react';
import { Plus, Loader2, CreditCard, DollarSign, AlertCircle } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';
import { formatCurrency, formatDate, PAYMENT_METHOD_LABELS, SALE_STATUS_COLORS, SALE_STATUS_LABELS } from '@/lib/constants';
import { PageHeader, Button, Modal, Input, Select, LoadingSpinner, ErrorState, EmptyState, Badge, StatCard } from '@/components/ui';
import type { Sale, Payment, PaymentMethod } from '@/types';
const METHODS: { value: PaymentMethod; label: string }[] = [{ value: 'cash', label: 'Cash' }, { value: 'bank_transfer', label: 'Bank Transfer' }, { value: 'mobile_money', label: 'Mobile Money' }, { value: 'check', label: 'Check' }, { value: 'other', label: 'Other' }];
const valid = (p: Payment) => ['completed', 'confirmed', 'approved'].includes(p.status);
export default function Payments() {
  const { user } = useAuth();
  const [sales, setSales] = useState<Sale[]>([]); const [loading, setLoading] = useState(true); const [error, setError] = useState<string | null>(null);
  const [selected, setSelected] = useState<Sale | null>(null); const [showForm, setShowForm] = useState(false); const [saving, setSaving] = useState(false);
  const [amount, setAmount] = useState(''); const [method, setMethod] = useState<PaymentMethod>('cash'); const [date, setDate] = useState(new Date().toISOString().slice(0, 10)); const [reference, setReference] = useState('');
  const load = async () => { setLoading(true); const { data, error } = await supabase.from('sales').select('*, customer:customers(*), payments(*)').order('created_at', { ascending: false }); if (error) setError(error.message); setSales((data ?? []) as unknown as Sale[]); setLoading(false); };
  useEffect(() => { void load(); }, []);
  const paid = (s: Sale) => (s.payments ?? []).filter(valid).reduce((n, p) => n + Number(p.amount), 0);
  const balance = (s: Sale) => Math.max(0, Number(s.total_amount) - paid(s));
  const record = async (ev: React.FormEvent) => { ev.preventDefault(); if (!selected) return; const n = Number(amount); if (!(n > 0) || n > balance(selected)) { setError('Enter an amount greater than zero and no more than the outstanding balance.'); return; }
    setSaving(true); setError(null);
    const { error } = await supabase.from('payments').insert({ sale_id: selected.id, amount: n, payment_method: method, reference_number: reference || null, recorded_by: user?.id ?? null, payment_date: date, status: 'completed' });
    if (error) { setError(error.message); setSaving(false); return; }
    const newPaid = paid(selected) + n; const nextStatus = newPaid >= Number(selected.total_amount) ? 'paid' : 'partial';
    const { error: statusError } = await supabase.from('sales').update({ status: nextStatus }).eq('id', selected.id);
    setSaving(false); if (statusError) setError(`Payment saved, but sale status could not be updated: ${statusError.message}`); setShowForm(false); setSelected(null); await load();
  };
  if (loading) return <LoadingSpinner label="Loading payments…" />;
  const outstanding = sales.filter((s) => balance(s) > 0); const collected = sales.reduce((n, s) => n + paid(s), 0); const totalOutstanding = outstanding.reduce((n, s) => n + balance(s), 0); const allPayments = sales.flatMap((s) => s.payments ?? []);
  return <div><PageHeader title="Payments" subtitle="Record customer payments and track balances." />{error && <div className="mb-4"><ErrorState message={error} /></div>}
    <div className="grid grid-cols-2 lg:grid-cols-3 gap-4 mb-6"><StatCard label="Total Collected" value={formatCurrency(collected, 'ETB')} icon={<DollarSign className="w-5 h-5" />} tone="success" /><StatCard label="Outstanding" value={formatCurrency(totalOutstanding, 'ETB')} icon={<AlertCircle className="w-5 h-5" />} tone="warning" /><StatCard label="Payments" value={String(allPayments.length)} icon={<CreditCard className="w-5 h-5" />} /></div>
    <h3 className="font-semibold mb-3">Sales with outstanding balances</h3>{outstanding.length === 0 ? <div className="bg-white rounded-xl border"><EmptyState icon={<CreditCard className="w-7 h-7" />} title="No outstanding balances" subtitle="All recorded sales are fully paid." /></div> : <div className="space-y-3">{outstanding.map((s) => <div key={s.id} className="bg-white rounded-xl border p-4 flex items-center justify-between gap-3"><div><div className="flex gap-2 items-center"><b>{s.sale_number}</b><Badge className={SALE_STATUS_COLORS[s.status] ?? ''}>{SALE_STATUS_LABELS[s.status] ?? s.status}</Badge></div><p className="text-sm text-slate-500">{s.customer?.full_name ?? '—'} · {formatDate(s.created_at)}</p><p className="text-sm mt-1">Total {formatCurrency(Number(s.total_amount), s.currency)} · Paid {formatCurrency(paid(s), s.currency)} · <b className="text-amber-700">Due {formatCurrency(balance(s), s.currency)}</b></p></div><Button size="sm" onClick={() => { setSelected(s); setAmount(String(balance(s))); setMethod('cash'); setDate(new Date().toISOString().slice(0,10)); setReference(''); setShowForm(true); }}><Plus className="w-4 h-4"/> Record</Button></div>)}</div>}
    <Modal open={showForm} onClose={() => setShowForm(false)} title="Record Payment"><form onSubmit={record} className="space-y-4">{selected && <div className="bg-slate-50 rounded-lg p-3 text-sm"><b>{selected.sale_number}</b> · {selected.customer?.full_name}<p>Outstanding: {formatCurrency(balance(selected), selected.currency)}</p></div>}<Input label="Amount (ETB)" type="number" min="0.01" step="0.01" value={amount} onChange={setAmount} required/><div className="grid grid-cols-2 gap-3"><Input label="Payment date" type="date" value={date} onChange={setDate} required/><Select label="Method" value={method} onChange={(v) => setMethod(v as PaymentMethod)} options={METHODS}/></div><Input label="Reference number (optional)" value={reference} onChange={setReference}/>{error && <ErrorState message={error}/>}<div className="flex justify-end gap-2"><Button type="button" variant="secondary" onClick={() => setShowForm(false)}>Cancel</Button><Button type="submit" disabled={saving}>{saving ? <Loader2 className="w-4 h-4 animate-spin"/> : <Plus className="w-4 h-4"/>} Save Payment</Button></div></form></Modal>
    <h3 className="font-semibold mt-8 mb-3">Recent payment records</h3><div className="bg-white border rounded-xl divide-y">{allPayments.sort((a,b) => b.payment_date.localeCompare(a.payment_date)).slice(0,30).map((p) => <div key={p.id} className="p-3 flex justify-between text-sm"><div><b>{sales.find((s) => s.id === p.sale_id)?.sale_number ?? 'Sale'}</b><p className="text-slate-500">{formatDate(p.payment_date)} · {PAYMENT_METHOD_LABELS[p.payment_method] ?? p.payment_method}</p></div><b>{formatCurrency(Number(p.amount), 'ETB')}</b></div>)}</div>
  </div>;
}
