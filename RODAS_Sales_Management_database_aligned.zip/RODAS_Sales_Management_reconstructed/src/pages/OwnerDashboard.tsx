import { useEffect, useState } from 'react';
import { DollarSign, TrendingUp, AlertCircle, Users, BadgeDollarSign, Wallet, ShoppingCart } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { formatCurrency, formatDate } from '@/lib/constants';
import { StatCard, LoadingSpinner, ErrorState, Badge } from '@/components/ui';
import type { Sale, CommissionEntry, EmployeeProfile, Payment } from '@/types';

export default function OwnerDashboard() {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [stats, setStats] = useState({
    totalSales: 0,
    totalPaid: 0,
    outstanding: 0,
    totalCommissions: 0,
    pendingCommissions: 0,
    employeeCount: 0,
    salesThisMonth: 0,
    saleCount: 0,
  });
  const [recentSales, setRecentSales] = useState<Sale[]>([]);
  const [pendingComms, setPendingComms] = useState<CommissionEntry[]>([]);
  const [topEmployees, setTopEmployees] = useState<{ employee: EmployeeProfile; total: number; count: number }[]>([]);

  useEffect(() => {
    (async () => {
      setLoading(true);
      setError(null);
      try {
        const [salesRes, paymentsRes, employeesRes, commsRes] = await Promise.all([
          supabase.from('sales').select('id, sale_number, total_amount, currency, status, created_at, customer:customers(full_name)').order('created_at', { ascending: false }),
          supabase.from('payments').select('amount, status'),
          supabase.from('employee_profiles').select('id, full_name, role, active').eq('active', true),
          supabase.from('commission_entries').select('id, commission_amount, approval_status, employee_id, employee_role, sale_id, payment_id, created_at, employee:employee_profiles(id, full_name, role), sale:sales(id, sale_number, total_amount, created_at)').order('created_at', { ascending: false }),
        ]);

        if (salesRes.error) throw salesRes.error;
        if (commsRes.error) throw commsRes.error;

        const sales = (salesRes.data ?? []) as unknown as Sale[];
        const payments = (paymentsRes.data ?? []) as unknown as Payment[];
        const commissions = (commsRes.data ?? []) as unknown as CommissionEntry[];

        const totalSales = sales.reduce((s, x) => s + Number(x.total_amount), 0);
        const totalPaid = payments
          .filter((p) => p.status === 'completed' || p.status === 'confirmed' || p.status === 'approved')
          .reduce((s, p) => s + Number(p.amount), 0);
        const outstanding = Math.max(0, totalSales - totalPaid);

        const now = new Date();
        const salesThisMonth = sales
          .filter((s) => {
            const d = new Date(s.created_at);
            return d.getMonth() === now.getMonth() && d.getFullYear() === now.getFullYear();
          })
          .reduce((sum, s) => sum + Number(s.total_amount), 0);

        const activeCommissions = commissions.filter((c) => c.status !== 'reversed');
        const totalCommissions = activeCommissions.reduce((s, c) => s + Number(c.commission_amount), 0);
        const pending = activeCommissions.filter((c) => !c.approval_status || c.approval_status === 'pending');
        const pendingTotal = pending.reduce((s, c) => s + Number(c.commission_amount), 0);

        const empMap = new Map<string, { employee: EmployeeProfile; total: number; count: number }>();
        for (const c of activeCommissions) {
          if (!c.employee) continue;
          const existing = empMap.get(c.employee_id);
          if (existing) {
            existing.total += Number(c.commission_amount);
            existing.count += 1;
          } else {
            empMap.set(c.employee_id, { employee: c.employee, total: Number(c.commission_amount), count: 1 });
          }
        }
        const top = Array.from(empMap.values()).sort((a, b) => b.total - a.total).slice(0, 5);

        setStats({
          totalSales,
          totalPaid,
          outstanding,
          totalCommissions,
          pendingCommissions: pendingTotal,
          employeeCount: (employeesRes.data ?? []).length,
          salesThisMonth,
          saleCount: sales.length,
        });
        setRecentSales(sales.slice(0, 6));
        setPendingComms(pending.slice(0, 5));
        setTopEmployees(top);
      } catch (err) {
        setError((err as Error).message);
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  if (loading) return <LoadingSpinner label="Loading dashboard…" />;
  if (error) return <ErrorState message={error} />;

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-slate-900">Dashboard</h1>
        <p className="text-sm text-slate-500 mt-1">Overview of sales, payments, and commissions.</p>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard label="Total Sales" value={formatCurrency(stats.totalSales)} icon={<TrendingUp className="w-5 h-5" />} tone="info" />
        <StatCard label="Collected" value={formatCurrency(stats.totalPaid)} icon={<Wallet className="w-5 h-5" />} tone="success" />
        <StatCard label="Outstanding" value={formatCurrency(stats.outstanding)} icon={<AlertCircle className="w-5 h-5" />} tone="warning" />
        <StatCard label="This Month" value={formatCurrency(stats.salesThisMonth)} icon={<DollarSign className="w-5 h-5" />} />
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard label="Active Employees" value={String(stats.employeeCount)} icon={<Users className="w-5 h-5" />} />
        <StatCard label="Total Commissions" value={formatCurrency(stats.totalCommissions)} icon={<BadgeDollarSign className="w-5 h-5" />} />
        <StatCard label="Pending Payouts" value={formatCurrency(stats.pendingCommissions)} icon={<BadgeDollarSign className="w-5 h-5" />} tone="warning" />
        <StatCard label="Sales Records" value={String(stats.saleCount)} icon={<ShoppingCart className="w-5 h-5" />} />
      </div>

      <div className="grid lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
          <div className="px-5 py-4 border-b border-slate-200">
            <h3 className="font-semibold text-slate-900">Recent Sales</h3>
          </div>
          {recentSales.length === 0 ? (
            <p className="px-5 py-8 text-center text-sm text-slate-400">No sales recorded yet.</p>
          ) : (
            <div className="divide-y divide-slate-100">
              {recentSales.map((s) => (
                <div key={s.id} className="px-5 py-3 flex items-center justify-between hover:bg-slate-50 transition">
                  <div>
                    <p className="font-medium text-slate-900 text-sm">{s.sale_number}</p>
                    <p className="text-xs text-slate-500">{(s as unknown as { customer?: { full_name?: string } }).customer?.full_name ?? '—'} · {formatDate(s.created_at)}</p>
                  </div>
                  <div className="flex items-center gap-3">
                    <span className="text-sm font-semibold text-slate-900">{formatCurrency(Number(s.total_amount), s.currency)}</span>
                    <Badge className="bg-slate-100 text-slate-600 capitalize">{s.status}</Badge>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
          <div className="px-5 py-4 border-b border-slate-200">
            <h3 className="font-semibold text-slate-900">Pending Commission Approvals</h3>
          </div>
          {pendingComms.length === 0 ? (
            <p className="px-5 py-8 text-center text-sm text-slate-400">No pending commissions.</p>
          ) : (
            <div className="divide-y divide-slate-100">
              {pendingComms.map((c) => (
                <div key={c.id} className="px-5 py-3 flex items-center justify-between hover:bg-slate-50 transition">
                  <div>
                    <p className="font-medium text-slate-900 text-sm">{c.employee?.full_name ?? '—'}</p>
                    <p className="text-xs text-slate-500">{c.sale?.sale_number ?? '—'} · {formatDate(c.created_at)}</p>
                  </div>
                  <span className="text-sm font-semibold text-slate-900">{formatCurrency(Number(c.commission_amount))}</span>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="px-5 py-4 border-b border-slate-200">
          <h3 className="font-semibold text-slate-900">Top Earners (Commissions)</h3>
        </div>
        {topEmployees.length === 0 ? (
          <p className="px-5 py-8 text-center text-sm text-slate-400">No commission data yet.</p>
        ) : (
          <div className="divide-y divide-slate-100">
            {topEmployees.map(({ employee, total, count }) => (
              <div key={employee.id} className="px-5 py-3 flex items-center justify-between hover:bg-slate-50 transition">
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-full bg-slate-200 flex items-center justify-center text-sm font-bold text-slate-600">
                    {employee.full_name.charAt(0).toUpperCase()}
                  </div>
                  <div>
                    <p className="font-medium text-slate-900 text-sm">{employee.full_name}</p>
                    <p className="text-xs text-slate-500">{count} commission{count !== 1 ? 's' : ''}</p>
                  </div>
                </div>
                <span className="text-sm font-semibold text-slate-900">{formatCurrency(total)}</span>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
