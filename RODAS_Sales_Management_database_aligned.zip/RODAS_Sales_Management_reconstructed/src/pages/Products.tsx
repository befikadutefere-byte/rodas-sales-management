import { useEffect, useState } from 'react';
import { PackagePlus, Pencil, Trash2, Loader2, Package, Search, Droplet } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { formatCurrency } from '@/lib/constants';
import { PageHeader, Button, Modal, Input, Select, Textarea, LoadingSpinner, ErrorState, EmptyState, Badge } from '@/components/ui';
import type { PaintProduct } from '@/types';

export default function Products() {
  const [products, setProducts] = useState<PaintProduct[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [search, setSearch] = useState('');
  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState<PaintProduct | null>(null);

  const [productCode, setProductCode] = useState('');
  const [productName, setProductName] = useState('');
  const [category, setCategory] = useState('');
  const [description, setDescription] = useState('');
  const [priceGallon, setPriceGallon] = useState('0');
  const [priceLitre, setPriceLitre] = useState('0');
  const [coverageGallon, setCoverageGallon] = useState('');
  const [coverageLitre, setCoverageLitre] = useState('');
  const [commPerGallon, setCommPerGallon] = useState('0');
  const [commPerLitre, setCommPerLitre] = useState('0');
  const [active, setActive] = useState(true);
  const [saving, setSaving] = useState(false);

  const load = async () => {
    setLoading(true);
    const { data, error } = await supabase.from('paint_products').select('*').order('created_at', { ascending: false });
    if (error) setError(error.message);
    else setProducts((data ?? []) as PaintProduct[]);
    setLoading(false);
  };

  useEffect(() => { load(); }, []);

  const resetForm = () => {
    setProductCode(''); setProductName(''); setCategory(''); setDescription('');
    setPriceGallon('0'); setPriceLitre('0'); setCoverageGallon(''); setCoverageLitre('');
    setCommPerGallon('0'); setCommPerLitre('0'); setActive(true);
  };

  const openCreate = () => { setEditing(null); resetForm(); setShowForm(true); };
  const openEdit = (p: PaintProduct) => {
    setEditing(p);
    setProductCode(p.product_code ?? '');
    setProductName(p.product_name);
    setCategory(p.category ?? '');
    setDescription(p.description ?? '');
    setPriceGallon(String(p.price_per_gallon));
    setPriceLitre(String(p.price_per_litre));
    setCoverageGallon(p.coverage_m2_per_gallon != null ? String(p.coverage_m2_per_gallon) : '');
    setCoverageLitre(p.coverage_m2_per_litre != null ? String(p.coverage_m2_per_litre) : '');
    setCommPerGallon(String(p.commission_per_gallon));
    setCommPerLitre(String(p.commission_per_litre));
    setActive(p.active);
    setShowForm(true);
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    setError(null);
    const payload = {
      product_code: productCode || null,
      product_name: productName,
      category: category || null,
      description: description || null,
      price_per_gallon: Number(priceGallon) || 0,
      price_per_litre: Number(priceLitre) || 0,
      coverage_m2_per_gallon: coverageGallon ? Number(coverageGallon) : null,
      coverage_m2_per_litre: coverageLitre ? Number(coverageLitre) : null,
      commission_per_gallon: Number(commPerGallon) || 0,
      commission_per_litre: Number(commPerLitre) || 0,
      active,
    };
    let res;
    if (editing) {
      res = await supabase.from('paint_products').update(payload).eq('id', editing.id);
    } else {
      res = await supabase.from('paint_products').insert(payload);
    }
    setSaving(false);
    if (res.error) { setError(res.error.message); return; }
    setShowForm(false);
    await load();
  };

  const handleDelete = async (p: PaintProduct) => {
    if (!confirm(`Delete product "${p.product_name}"?`)) return;
    const { error } = await supabase.from('paint_products').delete().eq('id', p.id);
    if (error) { setError(error.message); return; }
    await load();
  };

  const filtered = products.filter((p) => p.product_name.toLowerCase().includes(search.toLowerCase()) || (p.product_code ?? '').toLowerCase().includes(search.toLowerCase()));

  if (loading) return <LoadingSpinner label="Loading products…" />;

  return (
    <div>
      <PageHeader
        title="Product Catalogue"
        subtitle="Paint products with pricing and commission rates."
        action={<Button onClick={openCreate}><PackagePlus className="w-4 h-4" /> Add Product</Button>}
      />

      {error && <div className="mb-4"><ErrorState message={error} /></div>}

      <div className="mb-4 relative max-w-sm">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
        <input
          type="text"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Search by name or code…"
          className="w-full pl-11 pr-4 py-2.5 rounded-lg border border-slate-300 bg-white text-slate-900 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-600 focus:border-transparent transition"
        />
      </div>

      {filtered.length === 0 ? (
        <div className="bg-white rounded-xl border border-slate-200">
          <EmptyState icon={<Package className="w-7 h-7" />} title={search ? "No matching products" : "No products yet"} subtitle={search ? "Try a different search." : "Add your first paint product."} />
        </div>
      ) : (
        <>
          <div className="hidden lg:block bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
            <table className="w-full text-sm">
              <thead className="bg-slate-50 text-slate-600">
                <tr>
                  <th className="text-left px-5 py-3 font-medium">Code</th>
                  <th className="text-left px-5 py-3 font-medium">Product</th>
                  <th className="text-left px-5 py-3 font-medium">Category</th>
                  <th className="text-right px-5 py-3 font-medium">Price/Gal</th>
                  <th className="text-right px-5 py-3 font-medium">Price/L</th>
                  <th className="text-right px-5 py-3 font-medium">Comm/Gal</th>
                  <th className="text-right px-5 py-3 font-medium">Comm/L</th>
                  <th className="text-center px-5 py-3 font-medium">Status</th>
                  <th className="text-right px-5 py-3 font-medium">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filtered.map((p) => (
                  <tr key={p.id} className="hover:bg-slate-50 transition">
                    <td className="px-5 py-3 text-slate-500 font-mono text-xs">{p.product_code ?? '—'}</td>
                    <td className="px-5 py-3">
                      <div className="flex items-center gap-2">
                        <Droplet className="w-4 h-4 text-blue-500 flex-shrink-0" />
                        <span className="font-medium text-slate-900">{p.product_name}</span>
                      </div>
                    </td>
                    <td className="px-5 py-3 text-slate-600">{p.category ?? '—'}</td>
                    <td className="text-right px-5 py-3 text-slate-700">{formatCurrency(Number(p.price_per_gallon))}</td>
                    <td className="text-right px-5 py-3 text-slate-700">{formatCurrency(Number(p.price_per_litre))}</td>
                    <td className="text-right px-5 py-3 text-slate-700">{formatCurrency(Number(p.commission_per_gallon))}</td>
                    <td className="text-right px-5 py-3 text-slate-700">{formatCurrency(Number(p.commission_per_litre))}</td>
                    <td className="text-center px-5 py-3">
                      <Badge className={p.active ? 'bg-emerald-100 text-emerald-700' : 'bg-slate-100 text-slate-500'}>
                        {p.active ? 'Active' : 'Inactive'}
                      </Badge>
                    </td>
                    <td className="px-5 py-3">
                      <div className="flex justify-end gap-1">
                        <button onClick={() => openEdit(p)} className="p-1.5 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded transition"><Pencil className="w-4 h-4" /></button>
                        <button onClick={() => handleDelete(p)} className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded transition"><Trash2 className="w-4 h-4" /></button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <div className="lg:hidden grid sm:grid-cols-2 gap-4">
            {filtered.map((p) => (
              <div key={p.id} className="bg-white rounded-xl border border-slate-200 p-4 shadow-sm">
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-2">
                    <Droplet className="w-5 h-5 text-blue-500" />
                    <div>
                      <p className="font-semibold text-slate-900">{p.product_name}</p>
                      {p.product_code && <p className="text-xs font-mono text-slate-400">{p.product_code}</p>}
                    </div>
                  </div>
                  <Badge className={p.active ? 'bg-emerald-100 text-emerald-700' : 'bg-slate-100 text-slate-500'}>
                    {p.active ? 'Active' : 'Inactive'}
                  </Badge>
                </div>
                {p.description && <p className="text-xs text-slate-500 mt-1.5">{p.description}</p>}
                {p.category && <p className="text-xs text-slate-400 mt-1">Category: {p.category}</p>}
                <div className="mt-3 grid grid-cols-2 gap-2 text-sm">
                  <div><p className="text-xs text-slate-400">Price/Gallon</p><p className="font-medium text-slate-700">{formatCurrency(Number(p.price_per_gallon))}</p></div>
                  <div><p className="text-xs text-slate-400">Price/Litre</p><p className="font-medium text-slate-700">{formatCurrency(Number(p.price_per_litre))}</p></div>
                  <div><p className="text-xs text-slate-400">Comm/Gallon</p><p className="font-medium text-slate-700">{formatCurrency(Number(p.commission_per_gallon))}</p></div>
                  <div><p className="text-xs text-slate-400">Comm/Litre</p><p className="font-medium text-slate-700">{formatCurrency(Number(p.commission_per_litre))}</p></div>
                </div>
                <div className="mt-3 pt-3 border-t border-slate-100 flex gap-2">
                  <Button variant="secondary" size="sm" onClick={() => openEdit(p)}><Pencil className="w-3.5 h-3.5" /> Edit</Button>
                  <Button variant="ghost" size="sm" onClick={() => handleDelete(p)}><Trash2 className="w-3.5 h-3.5 text-rose-500" /></Button>
                </div>
              </div>
            ))}
          </div>
        </>
      )}

      <Modal open={showForm} onClose={() => setShowForm(false)} title={editing ? 'Edit Product' : 'Add Product'} size="lg">
        <form onSubmit={handleSave} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <Input label="Product Code" value={productCode} onChange={setProductCode} placeholder="RPI-001" />
            <Input label="Product Name" value={productName} onChange={setProductName} required placeholder="RODAS Premium Interior" />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <Input label="Category" value={category} onChange={setCategory} placeholder="Interior" />
          </div>
          <Textarea label="Description" value={description} onChange={setDescription} rows={2} />
          <div className="grid grid-cols-2 gap-4">
            <Input label="Price per Gallon ($)" type="number" step="0.01" min="0" value={priceGallon} onChange={setPriceGallon} required />
            <Input label="Price per Litre ($)" type="number" step="0.01" min="0" value={priceLitre} onChange={setPriceLitre} required />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <Input label="Coverage (m²/gallon)" type="number" step="0.01" min="0" value={coverageGallon} onChange={setCoverageGallon} placeholder="37" />
            <Input label="Coverage (m²/litre)" type="number" step="0.01" min="0" value={coverageLitre} onChange={setCoverageLitre} placeholder="10" />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <Input label="Commission per Gallon ($)" type="number" step="0.01" min="0" value={commPerGallon} onChange={setCommPerGallon} required />
            <Input label="Commission per Litre ($)" type="number" step="0.01" min="0" value={commPerLitre} onChange={setCommPerLitre} required />
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1.5">Status</label>
            <button type="button" onClick={() => setActive(!active)} className={`w-full px-4 py-2.5 rounded-lg border font-medium transition ${active ? 'border-emerald-300 bg-emerald-50 text-emerald-700' : 'border-slate-300 bg-white text-slate-600'}`}>
              {active ? 'Active' : 'Inactive'}
            </button>
          </div>
          {error && <ErrorState message={error} />}
          <div className="flex justify-end gap-3 pt-2">
            <Button variant="secondary" onClick={() => setShowForm(false)}>Cancel</Button>
            <Button type="submit" disabled={saving}>
              {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : null}
              {saving ? 'Saving…' : editing ? 'Save Changes' : 'Add Product'}
            </Button>
          </div>
        </form>
      </Modal>
    </div>
  );
}
