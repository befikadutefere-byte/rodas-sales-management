import { useEffect, useState } from 'react';
import { UserPlus, Phone, Pencil, Loader2, Users } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';
import { ROLE_LABELS, ROLE_COLORS, ROLE_OPTIONS, formatDate } from '@/lib/constants';
import { PageHeader, Button, Modal, Input, Select, LoadingSpinner, ErrorState, Badge } from '@/components/ui';
import type { EmployeeProfile, EmployeeRole } from '@/types';

export default function Employees() {
  const { user } = useAuth();
  const [employees, setEmployees] = useState<EmployeeProfile[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [edgeFunctionExists, setEdgeFunctionExists] = useState<boolean | null>(null);
  const [showCreate, setShowCreate] = useState(false);
  const [editing, setEditing] = useState<EmployeeProfile | null>(null);

  const [cName, setCName] = useState('');
  const [cEmail, setCEmail] = useState('');
  const [cPassword, setCPassword] = useState('');
  const [cRole, setCRole] = useState<EmployeeRole>('salesperson');
  const [cPhone, setCPhone] = useState('');
  const [creating, setCreating] = useState(false);
  const [createError, setCreateError] = useState<string | null>(null);

  const [eName, setEName] = useState('');
  const [ePhone, setEPhone] = useState('');
  const [eActive, setEActive] = useState(true);
  const [saving, setSaving] = useState(false);

  const load = async () => {
    setLoading(true);
    setError(null);
    const { data, error } = await supabase.from('employee_profiles').select('*').order('created_at', { ascending: false });
    if (error) setError(error.message);
    else setEmployees((data ?? []) as EmployeeProfile[]);
    setLoading(false);
  };

  useEffect(() => {
    load();
    // Check if create-employee edge function exists by probing it
    (async () => {
      try {
        const apiUrl = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/create-employee`;
        const res = await fetch(apiUrl, { method: 'OPTIONS' });
        setEdgeFunctionExists(res.ok || res.status === 204 || res.status === 400);
      } catch {
        setEdgeFunctionExists(false);
      }
    })();
  }, []);

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    setCreating(true);
    setCreateError(null);
    try {
      const apiUrl = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/create-employee`;
      const { data: sessionData } = await supabase.auth.getSession();
      const res = await fetch(apiUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${sessionData.session?.access_token}`,
        },
        body: JSON.stringify({
          email: cEmail,
          password: cPassword,
          fullName: cName,
          role: cRole,
          phone: cPhone || undefined,
        }),
      });
      const json = await res.json();
      if (!res.ok || json.error) {
        throw new Error(json.error ?? `Failed (${res.status})`);
      }
      setShowCreate(false);
      setCName(''); setCEmail(''); setCPassword(''); setCRole('salesperson'); setCPhone('');
      await load();
    } catch (err) {
      setCreateError((err as Error).message);
    } finally {
      setCreating(false);
    }
  };

  const openEdit = (emp: EmployeeProfile) => {
    setEditing(emp);
    setEName(emp.full_name);
    setEPhone(emp.phone ?? '');
    setEActive(emp.active);
  };

  const handleSaveEdit = async () => {
    if (!editing) return;
    setSaving(true);
    const { error } = await supabase
      .from('employee_profiles')
      .update({ full_name: eName, phone: ePhone || null, active: eActive })
      .eq('id', editing.id);
    setSaving(false);
    if (error) { setError(error.message); return; }
    setEditing(null);
    await load();
  };

  if (loading) return <LoadingSpinner label="Loading employees…" />;
  if (error) return <ErrorState message={error} />;

  return (
    <div>
      <PageHeader
        title="Employees"
        subtitle="Manage staff accounts and roles."
        action={
          edgeFunctionExists ? (
            <Button onClick={() => setShowCreate(true)}><UserPlus className="w-4 h-4" /> Add Employee</Button>
          ) : (
            <span className="text-sm text-slate-400">Employee creation requires the create-employee function</span>
          )
        }
      />

      {edgeFunctionExists === false && (
        <div className="mb-4 rounded-lg bg-amber-50 border border-amber-200 px-4 py-3 text-sm text-amber-700">
          The "create-employee" Edge Function was not found in this Supabase project. New employee accounts cannot be created from the app until it is deployed. Existing employees can still be edited.
        </div>
      )}

      {employees.length === 0 ? (
        <div className="bg-white rounded-xl border border-slate-200 p-8 text-center text-slate-400">
          <Users className="w-12 h-12 mx-auto mb-3 text-slate-300" />
          <p>No employees found in employee_profiles.</p>
        </div>
      ) : (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {employees.map((emp) => (
            <div key={emp.id} className="bg-white rounded-xl border border-slate-200 p-5 shadow-sm hover:shadow-md transition">
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-3">
                  <div className={`w-11 h-11 rounded-full flex items-center justify-center font-bold ${ROLE_COLORS[emp.role] ?? 'bg-slate-600 text-white'}`}>
                    {emp.full_name.charAt(0).toUpperCase()}
                  </div>
                  <div>
                    <p className="font-semibold text-slate-900">{emp.full_name}</p>
                    <Badge className={ROLE_COLORS[emp.role] ?? 'bg-slate-600 text-white'}>{ROLE_LABELS[emp.role] ?? emp.role}</Badge>
                  </div>
                </div>
              </div>
              <div className="mt-4 space-y-1.5 text-sm text-slate-600">
                {emp.phone && <p className="flex items-center gap-2"><Phone className="w-4 h-4 text-slate-400" /> {emp.phone}</p>}
                <p className="text-slate-400">Joined {formatDate(emp.created_at)}</p>
                <p className={`font-medium ${emp.active ? 'text-emerald-600' : 'text-slate-400'}`}>
                  · {emp.active ? 'Active' : 'Inactive'}
                </p>
              </div>
              {emp.id !== user?.id && (
                <div className="mt-4 pt-4 border-t border-slate-100">
                  <Button variant="secondary" size="sm" onClick={() => openEdit(emp)}>
                    <Pencil className="w-3.5 h-3.5" /> Edit
                  </Button>
                </div>
              )}
            </div>
          ))}
        </div>
      )}

      <Modal open={showCreate} onClose={() => setShowCreate(false)} title="Create Employee Account">
        <form onSubmit={handleCreate} className="space-y-4">
          <Input label="Full Name" value={cName} onChange={setCName} required placeholder="Jane Doe" />
          <Input label="Email Address" type="email" value={cEmail} onChange={setCEmail} required placeholder="jane@rodaspaint.com" />
          <Input label="Temporary Password" type="password" value={cPassword} onChange={setCPassword} required placeholder="Min 6 characters" />
          <Select label="Role" value={cRole} onChange={(v) => setCRole(v as EmployeeRole)} options={ROLE_OPTIONS} required />
          <Input label="Phone (optional)" value={cPhone} onChange={setCPhone} placeholder="+1 555-0100" />
          {createError && <ErrorState message={createError} />}
          <div className="flex justify-end gap-3 pt-2">
            <Button variant="secondary" onClick={() => setShowCreate(false)}>Cancel</Button>
            <Button type="submit" disabled={creating}>
              {creating ? <Loader2 className="w-4 h-4 animate-spin" /> : <UserPlus className="w-4 h-4" />}
              {creating ? 'Creating…' : 'Create Account'}
            </Button>
          </div>
          <p className="text-xs text-slate-400">
            A login account will be created for this employee. They can sign in immediately with the email and password above.
          </p>
        </form>
      </Modal>

      <Modal open={!!editing} onClose={() => setEditing(null)} title="Edit Employee">
        <div className="space-y-4">
          <Input label="Full Name" value={eName} onChange={setEName} required />
          <Input label="Phone" value={ePhone} onChange={setEPhone} placeholder="Optional" />
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1.5">Status</label>
            <button
              onClick={() => setEActive(!eActive)}
              className={`w-full px-4 py-2.5 rounded-lg border font-medium transition ${
                eActive ? 'border-emerald-300 bg-emerald-50 text-emerald-700' : 'border-slate-300 bg-white text-slate-600'
              }`}
            >
              {eActive ? 'Active' : 'Inactive'}
            </button>
          </div>
          {error && <ErrorState message={error} />}
          <div className="flex justify-end gap-3 pt-2">
            <Button variant="secondary" onClick={() => setEditing(null)}>Cancel</Button>
            <Button onClick={handleSaveEdit} disabled={saving}>
              {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : null}
              {saving ? 'Saving…' : 'Save Changes'}
            </Button>
          </div>
        </div>
      </Modal>
    </div>
  );
}
