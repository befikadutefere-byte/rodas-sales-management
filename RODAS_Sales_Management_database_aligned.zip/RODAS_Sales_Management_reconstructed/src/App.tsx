import { useState } from 'react';
import { AuthProvider, useAuth } from '@/context/AuthContext';
import Login from '@/pages/Login';
import AppLayout, { type PageId } from '@/components/AppLayout';
import OwnerDashboard from '@/pages/OwnerDashboard';
import Employees from '@/pages/Employees';
import Customers from '@/pages/Customers';
import Products from '@/pages/Products';
import Sales from '@/pages/Sales';
import Payments from '@/pages/Payments';
import Commissions from '@/pages/Commissions';
import Reports from '@/pages/Reports';
import { LoadingSpinner } from '@/components/ui';

function isOwner(role: string | undefined): boolean {
  return role === 'owner' || role === 'company_owner';
}

function AppContent() {
  const { session, employee, loading } = useAuth();
  const [page, setPage] = useState<PageId>('dashboard');

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50">
        <LoadingSpinner label="Loading…" />
      </div>
    );
  }

  if (!session || !employee) {
    return <Login />;
  }

  const owner = isOwner(employee.role);
  const activePage = page === 'dashboard' && !owner ? 'reports' : page;

  const renderPage = () => {
    switch (activePage) {
      case 'dashboard':
        return owner ? <OwnerDashboard /> : <Reports />;
      case 'employees':
        return <Employees />;
      case 'customers':
        return <Customers />;
      case 'products':
        return <Products />;
      case 'sales':
        return <Sales />;
      case 'payments':
        return <Payments />;
      case 'commissions':
        return <Commissions />;
      case 'reports':
        return <Reports />;
      default:
        return <Reports />;
    }
  };

  return (
    <AppLayout page={activePage} onPageChange={setPage}>
      {renderPage()}
    </AppLayout>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}
