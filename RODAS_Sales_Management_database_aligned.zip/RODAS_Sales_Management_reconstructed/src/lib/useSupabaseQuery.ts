import { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabase';

export function useSupabaseQuery<T>(
  fetcher: () => Promise<{ data: T | null; error: { message: string } | null }>,
  deps: unknown[] = [],
) {
  const [data, setData] = useState<T | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let mounted = true;
    setLoading(true);
    fetcher()
      .then(({ data, error }) => {
        if (!mounted) return;
        if (error) setError(error.message);
        else {
          setData(data);
          setError(null);
        }
      })
      .finally(() => mounted && setLoading(false));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, deps);

  return { data, error, loading, refetch: () => setLoading(true) };
}
