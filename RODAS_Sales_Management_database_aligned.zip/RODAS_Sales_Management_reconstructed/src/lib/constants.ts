import type { EmployeeRole } from '@/types';

export const ROLE_LABELS: Record<string, string> = {
  owner: 'Company Owner',
  marketing_manager: 'Marketing Manager',
  sales_supervisor: 'Sales Supervisor',
  order_taker: 'Order Taker',
  salesperson: 'Salesperson',
  company_owner: 'Company Owner',
};

export const ROLE_COLORS: Record<string, string> = {
  owner: 'bg-slate-900 text-white',
  company_owner: 'bg-slate-900 text-white',
  marketing_manager: 'bg-blue-600 text-white',
  sales_supervisor: 'bg-teal-600 text-white',
  order_taker: 'bg-amber-600 text-white',
  salesperson: 'bg-emerald-600 text-white',
};

export const COMMISSION_RATES: Record<string, number> = {
  marketing_manager: 60,
  sales_supervisor: 24,
  order_taker: 10,
  salesperson: 6,
};

export const formatCurrency = (value: number, currency = 'USD'): string => {
  try {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: currency || 'USD',
      minimumFractionDigits: 2,
    }).format(value || 0);
  } catch {
    return `${(value || 0).toFixed(2)} ${currency}`;
  }
};

export const formatDate = (value: string): string => {
  if (!value) return '—';
  return new Date(value).toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
  });
};

export const formatDateTime = (value: string): string => {
  if (!value) return '—';
  return new Date(value).toLocaleString('en-US', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });
};

export const formatPercent = (value: number): string => {
  return `${value.toFixed(0)}%`;
};

export const ROLE_OPTIONS: { value: EmployeeRole; label: string }[] = [
  { value: 'marketing_manager', label: 'Marketing Manager' },
  { value: 'sales_supervisor', label: 'Sales Supervisor' },
  { value: 'order_taker', label: 'Order Taker' },
  { value: 'salesperson', label: 'Salesperson' },
  { value: 'owner', label: 'Company Owner' },
];

export const SALE_STATUS_LABELS: Record<string, string> = {
  pending: 'Pending', partial: 'Partially Paid', paid: 'Paid', cancelled: 'Cancelled',
};
export const SALE_STATUS_COLORS: Record<string, string> = {
  pending: 'bg-amber-100 text-amber-700', partial: 'bg-blue-100 text-blue-700', paid: 'bg-emerald-100 text-emerald-700', cancelled: 'bg-rose-100 text-rose-700',
};
export const COMMISSION_STATUS_LABELS: Record<string, string> = {
  pending: 'Pending approval', approved: 'Approved', paid: 'Paid', cancelled: 'Cancelled',
};
export const COMMISSION_STATUS_COLORS: Record<string, string> = {
  pending: 'bg-amber-100 text-amber-700', approved: 'bg-blue-100 text-blue-700', paid: 'bg-emerald-100 text-emerald-700', cancelled: 'bg-rose-100 text-rose-700',
};
export const PAYMENT_METHOD_LABELS: Record<string, string> = {
  cash: 'Cash', bank_transfer: 'Bank Transfer', mobile_money: 'Mobile Money', check: 'Check', other: 'Other',
};
