import { useState, type ReactNode } from 'react';
import {
  LayoutDashboard,
  Users,
  UserCircle,
  Package,
  ShoppingCart,
  CreditCard,
  BadgeDollarSign,
  BarChart3,
  LogOut,
  Menu,
  X,
  PaintRoller,
  ChevronDown,
} from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { ROLE_LABELS, ROLE_COLORS } from '@/lib/constants';

export type PageId =
  | 'dashboard'
  | 'employees'
  | 'customers'
  | 'products'
  | 'sales'
  | 'payments'
  | 'commissions'
  | 'reports';

const ALL_ROLES = ['owner', 'company_owner', 'marketing_manager', 'sales_supervisor', 'order_taker', 'salesperson'];

interface NavItem {
  id: PageId;
  label: string;
  icon: ReactNode;
  roles: string[];
}

const NAV_ITEMS: NavItem[] = [
  { id: 'dashboard', label: 'Dashboard', icon: <LayoutDashboard className="w-5 h-5" />, roles: ['owner', 'company_owner'] },
  { id: 'employees', label: 'Employees', icon: <Users className="w-5 h-5" />, roles: ['owner', 'company_owner'] },
  { id: 'customers', label: 'Customers', icon: <UserCircle className="w-5 h-5" />, roles: ALL_ROLES },
  { id: 'products', label: 'Products', icon: <Package className="w-5 h-5" />, roles: ALL_ROLES },
  { id: 'sales', label: 'Record Sale', icon: <ShoppingCart className="w-5 h-5" />, roles: ALL_ROLES },
  { id: 'payments', label: 'Payments', icon: <CreditCard className="w-5 h-5" />, roles: ['owner', 'company_owner', 'sales_supervisor', 'order_taker'] },
  { id: 'commissions', label: 'Commissions', icon: <BadgeDollarSign className="w-5 h-5" />, roles: ['owner', 'company_owner'] },
  { id: 'reports', label: 'Reports', icon: <BarChart3 className="w-5 h-5" />, roles: ALL_ROLES },
];

function normalizeRole(role: string): string {
  return role === 'company_owner' ? 'owner' : role;
}

export default function AppLayout({
  page,
  onPageChange,
  children,
}: {
  page: PageId;
  onPageChange: (p: PageId) => void;
  children: ReactNode;
}) {
  const { employee, user, signOut } = useAuth();
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [userMenuOpen, setUserMenuOpen] = useState(false);

  if (!employee) return null;
  const role = normalizeRole(employee.role);
  const visibleItems = NAV_ITEMS.filter((n) => n.roles.includes(role) || n.roles.includes(employee.role));
  const currentItem = visibleItems.find((n) => n.id === page) ?? visibleItems[0];

  const navigate = (p: PageId) => {
    onPageChange(p);
    setSidebarOpen(false);
  };

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Mobile top bar */}
      <div className="lg:hidden sticky top-0 z-30 bg-slate-900 text-white flex items-center justify-between px-4 py-3">
        <div className="flex items-center gap-2">
          <PaintRoller className="w-6 h-6" />
          <span className="font-bold">RODAS</span>
        </div>
        <button onClick={() => setSidebarOpen(true)} className="p-2 -mr-2">
          <Menu className="w-6 h-6" />
        </button>
      </div>

      {/* Sidebar */}
      <aside
        className={`fixed inset-y-0 left-0 z-40 w-72 bg-slate-900 text-slate-300 flex flex-col transform transition-transform lg:translate-x-0 ${
          sidebarOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'
        }`}
      >
        <div className="flex items-center justify-between px-6 py-5 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-white/10 flex items-center justify-center ring-1 ring-white/20">
              <PaintRoller className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-white font-bold text-lg leading-none">RODAS</h1>
              <p className="text-xs text-slate-400 mt-0.5">Sales Management</p>
            </div>
          </div>
          <button onClick={() => setSidebarOpen(false)} className="lg:hidden text-slate-400 hover:text-white">
            <X className="w-6 h-6" />
          </button>
        </div>

        <nav className="flex-1 overflow-y-auto py-4 px-3 space-y-1">
          {visibleItems.map((item) => (
            <button
              key={item.id}
              onClick={() => navigate(item.id)}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition ${
                page === item.id
                  ? 'bg-white text-slate-900'
                  : 'text-slate-300 hover:bg-slate-800 hover:text-white'
              }`}
            >
              {item.icon}
              {item.label}
            </button>
          ))}
        </nav>

        <div className="border-t border-slate-800 p-3">
          <div className="flex items-center gap-3 px-3 py-2">
            <div className={`w-9 h-9 rounded-full flex items-center justify-center text-sm font-bold ${ROLE_COLORS[role] ?? 'bg-slate-600 text-white'}`}>
              {employee.full_name.charAt(0).toUpperCase()}
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium text-white truncate">{employee.full_name}</p>
              <p className="text-xs text-slate-400">{ROLE_LABELS[role] ?? role}</p>
            </div>
          </div>
          <button
            onClick={signOut}
            className="w-full mt-2 flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium text-slate-300 hover:bg-slate-800 hover:text-white transition"
          >
            <LogOut className="w-5 h-5" />
            Sign out
          </button>
        </div>
      </aside>

      {/* Overlay */}
      {sidebarOpen && (
        <div className="fixed inset-0 z-30 bg-slate-900/50 lg:hidden" onClick={() => setSidebarOpen(false)} />
      )}

      {/* Main content */}
      <div className="lg:pl-72">
        {/* Desktop header */}
        <header className="hidden lg:flex sticky top-0 z-20 bg-white/80 backdrop-blur border-b border-slate-200 px-8 py-4 items-center justify-between">
          <h2 className="text-lg font-semibold text-slate-900">{currentItem?.label}</h2>
          <div className="relative">
            <button
              onClick={() => setUserMenuOpen(!userMenuOpen)}
              className="flex items-center gap-2 px-3 py-2 rounded-lg hover:bg-slate-100 transition"
            >
              <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold ${ROLE_COLORS[role] ?? 'bg-slate-600 text-white'}`}>
                {employee.full_name.charAt(0).toUpperCase()}
              </div>
              <div className="text-left">
                <p className="text-sm font-medium text-slate-900">{employee.full_name}</p>
                <p className="text-xs text-slate-500">{ROLE_LABELS[role] ?? role}</p>
              </div>
              <ChevronDown className="w-4 h-4 text-slate-400" />
            </button>
            {userMenuOpen && (
              <>
                <div className="fixed inset-0 z-10" onClick={() => setUserMenuOpen(false)} />
                <div className="absolute right-0 mt-2 w-56 bg-white rounded-lg shadow-lg border border-slate-200 py-1 z-20">
                  <div className="px-4 py-2 border-b border-slate-100">
                    <p className="text-sm font-medium text-slate-900">{employee.full_name}</p>
                    <p className="text-xs text-slate-500 truncate">{user?.email}</p>
                  </div>
                  <button
                    onClick={() => { setUserMenuOpen(false); signOut(); }}
                    className="w-full flex items-center gap-2 px-4 py-2.5 text-sm text-slate-700 hover:bg-slate-50 transition"
                  >
                    <LogOut className="w-4 h-4" />
                    Sign out
                  </button>
                </div>
              </>
            )}
          </div>
        </header>

        <main className="p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto">{children}</main>
      </div>
    </div>
  );
}
