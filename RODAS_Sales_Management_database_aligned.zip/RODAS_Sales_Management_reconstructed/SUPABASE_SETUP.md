# RODAS Sales Management — Supabase connection

This project is configured for the existing RODAS Supabase project:

`https://ixnhginpisxzkwepovxd.supabase.co`

## Add the public client key locally

1. Copy `.env.example` and name the copy `.env` in the project root (the same folder as `package.json`).
2. Open `.env` in a text editor.
3. Replace `PASTE_YOUR_ORIGINAL_SUPABASE_PUBLISHABLE_KEY_HERE` with the Publishable key (or legacy anon public key) from the original Supabase project.
4. Save the file.
5. Never put a `service_role` or secret key in this file. Never commit `.env` or share it publicly.
6. Restart the development server after changing `.env`.

The browser app uses `VITE_SUPABASE_ANON_KEY`; the Supabase publishable key is accepted as the public client key.

## Important safety note

Do not run `DO_NOT_RUN_wrong_database_schema.sql` or apply any database migration from this export to the original database. The application must use the existing schema and its existing commission trigger.
